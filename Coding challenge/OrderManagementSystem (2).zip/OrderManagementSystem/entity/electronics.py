from entity.product import Product

class Electronics(Product):
    def __init__(self, product_id=None, product_name=None, description=None, price=0.0,
                 quantity_in_stock=0, type_="Electronics", brand=None, warranty_period=0):
        super().__init__(product_id, product_name, description, price, quantity_in_stock, type_)
        self._brand = brand
        self._warranty_period = warranty_period

    # Getters
    def get_brand(self):
        return self._brand

    def get_warranty_period(self):
        return self._warranty_period

    # Setters
    def set_brand(self, brand):
        self._brand = brand

    def set_warranty_period(self, warranty_period):
        self._warranty_period = warranty_period

    # String representation
    def __str__(self):
        return (super().__str__() + 
                f", Brand: {self._brand}, Warranty Period: {self._warranty_period} months")
