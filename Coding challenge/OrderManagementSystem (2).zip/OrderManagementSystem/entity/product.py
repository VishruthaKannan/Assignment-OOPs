class Product:
    def __init__(self, product_id=None, product_name=None, description=None, price=0.0, quantity_in_stock=0, type_=None):
        self._product_id = product_id
        self._product_name = product_name
        self._description = description
        self._price = price
        self._quantity_in_stock = quantity_in_stock
        self._type = type_

    # Getters
    def get_product_id(self):
        return self._product_id

    def get_product_name(self):
        return self._product_name

    def get_description(self):
        return self._description

    def get_price(self):
        return self._price

    def get_quantity_in_stock(self):
        return self._quantity_in_stock

    def get_type(self):
        return self._type

    # Setters
    def set_product_id(self, product_id):
        self._product_id = product_id

    def set_product_name(self, product_name):
        self._product_name = product_name

    def set_description(self, description):
        self._description = description

    def set_price(self, price):
        self._price = price

    def set_quantity_in_stock(self, quantity_in_stock):
        self._quantity_in_stock = quantity_in_stock

    def set_type(self, type_):
        self._type = type_

    # String representation
    def __str__(self):
        return (f"Product ID: {self._product_id}, Name: {self._product_name}, "
                f"Description: {self._description}, Price: {self._price}, "
                f"Quantity: {self._quantity_in_stock}, Type: {self._type}")
