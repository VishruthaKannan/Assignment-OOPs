class User:
    def __init__(self, user_id=None, username=None, password=None, role=None):
        self._user_id = user_id
        self._username = username
        self._password = password
        self._role = role  # Should be "Admin" or "User"

    # Getters
    def get_user_id(self):
        return self._user_id

    def get_username(self):
        return self._username

    def get_password(self):
        return self._password

    def get_role(self):
        return self._role

    # Setters
    def set_user_id(self, user_id):
        self._user_id = user_id

    def set_username(self, username):
        self._username = username

    def set_password(self, password):
        self._password = password

    def set_role(self, role):
        self._role = role

    # String representation
    def __str__(self):
        return (f"User ID: {self._user_id}, Username: {self._username}, "
                f"Role: {self._role}")
