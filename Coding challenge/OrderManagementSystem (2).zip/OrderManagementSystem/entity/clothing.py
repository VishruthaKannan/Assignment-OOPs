from entity.product import Product

class Clothing(Product):
    def __init__(self, product_id=None, product_name=None, description=None, price=0.0,
                 quantity_in_stock=0, type_="Clothing", size=None, color=None):
        super().__init__(product_id, product_name, description, price, quantity_in_stock, type_)
        self._size = size
        self._color = color

    # Getters
    def get_size(self):
        return self._size

    def get_color(self):
        return self._color

    # Setters
    def set_size(self, size):
        self._size = size

    def set_color(self, color):
        self._color = color

    # String representation
    def __str__(self):
        return (super().__str__() + 
                f", Size: {self._size}, Color: {self._color}")
