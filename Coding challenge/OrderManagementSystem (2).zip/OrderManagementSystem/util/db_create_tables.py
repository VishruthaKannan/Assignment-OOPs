import sqlite3

def create_tables():
    conn = sqlite3.connect('order_management.db')  # Creates a local SQLite database
    cursor = conn.cursor()

    # Create users table
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS users (
        user_id INTEGER PRIMARY KEY,
        username TEXT NOT NULL,
        password TEXT NOT NULL,
        role TEXT CHECK(role IN ('Admin', 'User')) NOT NULL
    )
    ''')

    # Create products table
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS products (
        product_id INTEGER PRIMARY KEY,
        product_name TEXT NOT NULL,
        description TEXT,
        price REAL NOT NULL,
        quantity_in_stock INTEGER NOT NULL,
        type TEXT CHECK(type IN ('Electronics', 'Clothing')) NOT NULL,
        brand TEXT,             -- Specific to Electronics
        warranty_period INTEGER, -- Specific to Electronics
        size TEXT,               -- Specific to Clothing
        color TEXT               -- Specific to Clothing
    )
    ''')

    # Create orders table
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS orders (
        order_id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        product_id INTEGER,
        order_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(user_id),
        FOREIGN KEY (product_id) REFERENCES products(product_id)
    )
    ''')

    conn.commit()
    print("Tables created successfully.")
    conn.close()

if __name__ == "__main__":
    create_tables()
