import sqlite3  # or you can switch to MySQL/PostgreSQL as needed

class DBUtil:

    @staticmethod
    def get_db_conn():
        """
        Establishes and returns a connection to the database.
        """
        try:
            # Example with SQLite (local database file). For MySQL, you would use pymysql or mysql.connector
            conn = sqlite3.connect('order_management.db')  # this will create a DB file if it doesn't exist
            print("[DBUtil] Database connection established successfully.")
            return conn
        except Exception as e:
            print(f"[DBUtil] Failed to connect to the database. Error: {e}")
            return None
