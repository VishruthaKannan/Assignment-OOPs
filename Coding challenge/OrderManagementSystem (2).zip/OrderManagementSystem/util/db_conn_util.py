import sqlite3
from util.db_property_util import get_connection_string

def get_connection():
    props = get_connection_string("db.properties")
    conn = sqlite3.connect(props['db.url'])
    return conn
