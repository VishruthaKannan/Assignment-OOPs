from dao.product_service import ProductService
from exception.product_not_found_exception import ProductNotFoundException
from util.db_conn_util import get_connection
from entity.product import Product

class ProductServiceImpl(ProductService):

    def __init__(self):
        self.conn = get_connection()

    def add_product(self, product):
        cursor = self.conn.cursor()
        cursor.execute('''
            INSERT INTO product (productId, productName, description, price, quantityInStock, type)
            VALUES (?, ?, ?, ?, ?, ?)
        ''', (product.product_id, product.product_name, product.description, product.price, product.quantity_in_stock, product.type))
        self.conn.commit()

    def get_product_by_id(self, product_id):
        cursor = self.conn.cursor()
        cursor.execute('SELECT * FROM product WHERE productId = ?', (product_id,))
        row = cursor.fetchone()
        if row:
            return Product(*row)
        else:
            raise ProductNotFoundException(f"Product with ID {product_id} not found.")

    def get_all_products(self):
        cursor = self.conn.cursor()
        cursor.execute('SELECT * FROM product')
        rows = cursor.fetchall()
        return [Product(*row) for row in rows]

    def update_product(self, product):
        cursor = self.conn.cursor()
        cursor.execute('''
            UPDATE product
            SET productName = ?, description = ?, price = ?, quantityInStock = ?, type = ?
            WHERE productId = ?
        ''', (product.product_name, product.description, product.price, product.quantity_in_stock, product.type, product.product_id))
        if cursor.rowcount == 0:
            raise ProductNotFoundException(f"Product with ID {product.product_id} not found.")
        self.conn.commit()

    def delete_product(self, product_id):
        cursor = self.conn.cursor()
        cursor.execute('DELETE FROM product WHERE productId = ?', (product_id,))
        if cursor.rowcount == 0:
            raise ProductNotFoundException(f"Product with ID {product_id} not found.")
        self.conn.commit()
