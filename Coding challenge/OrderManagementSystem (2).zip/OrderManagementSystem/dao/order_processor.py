from dao.i_order_management_repository import IOrderManagementRepository
from exception.user_not_found_exception import UserNotFoundException
from exception.order_not_found_exception import OrderNotFoundException

class OrderProcessor(IOrderManagementRepository):

    def create_order(self, user, products):
        # Logic to:
        # 1. Check if user exists -> If not, create user
        # 2. Create an order with the products
        print(f"[create_order] Creating order for user {user.get_username()} with products {products}")

    def cancel_order(self, user_id, order_id):
        # Logic to:
        # 1. Check if user_id and order_id exist
        # 2. If not, raise UserNotFoundException or OrderNotFoundException
        print(f"[cancel_order] Cancelling order {order_id} for user {user_id}")

    def create_product(self, user, product):
        # Logic to:
        # 1. Check if user is Admin
        # 2. Create product if user is Admin
        print(f"[create_product] Admin {user.get_username()} creating product {product.get_product_name()}")

    def create_user(self, user):
        # Logic to:
        # 1. Store user into database
        print(f"[create_user] Creating user {user.get_username()}")

    def get_all_products(self):
        # Logic to:
        # 1. Fetch all products from database
        print("[get_all_products] Fetching all products")
        return []

    def get_order_by_user(self, user):
        # Logic to:
        # 1. Fetch orders placed by a specific user
        print(f"[get_order_by_user] Fetching orders for user {user.get_username()}")
        return []
