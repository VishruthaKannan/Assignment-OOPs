from abc import ABC, abstractmethod

class IOrderManagementRepository(ABC):

    @abstractmethod
    def create_order(self, user, products):
        """
        Create an order for a user.
        If user does not exist, create the user first.
        :param user: User object
        :param products: List of Product objects
        """
        pass

    @abstractmethod
    def cancel_order(self, user_id, order_id):
        """
        Cancel an order given user_id and order_id.
        If user_id or order_id not found, throw appropriate exception.
        """
        pass

    @abstractmethod
    def create_product(self, user, product):
        """
        Create a product in the database.
        Only Admin users can create a product.
        """
        pass

    @abstractmethod
    def create_user(self, user):
        """
        Create a new user and store it in the database.
        """
        pass

    @abstractmethod
    def get_all_products(self):
        """
        Return a list of all products in the database.
        """
        pass

    @abstractmethod
    def get_order_by_user(self, user):
        """
        Return all products ordered by a specific user.
        """
        pass
