from dao.order_processor import OrderProcessor
from entity.user import User
from entity.electronics import Electronics
from entity.clothing import Clothing

class OrderManagement:

    @staticmethod
    def main():
        processor = OrderProcessor()

        while True:
            print("\n====== Order Management System ======")
            print("1. Create User")
            print("2. Create Product")
            print("3. Cancel Order")
            print("4. Get All Products")
            print("5. Get Order by User")
            print("6. Exit")

            choice = input("Enter your choice (1-6): ")

            if choice == '1':
                user_id = int(input("Enter User ID: "))
                username = input("Enter Username: ")
                password = input("Enter Password: ")
                role = input("Enter Role (Admin/User): ")
                user = User(user_id, username, password, role)
                processor.create_user(user)

            elif choice == '2':
                user_id = int(input("Enter Admin User ID: "))
                username = input("Enter Admin Username: ")
                password = input("Enter Admin Password: ")
                role = "Admin"
                admin_user = User(user_id, username, password, role)

                print("Product Type: \n1. Electronics \n2. Clothing")
                product_type = input("Choose Product Type (1/2): ")

                product_id = int(input("Enter Product ID: "))
                product_name = input("Enter Product Name: ")
                description = input("Enter Product Description: ")
                price = float(input("Enter Product Price: "))
                quantity = int(input("Enter Quantity in Stock: "))

                if product_type == '1':
                    brand = input("Enter Brand: ")
                    warranty = int(input("Enter Warranty Period (in months): "))
                    product = Electronics(product_id, product_name, description, price, quantity, brand, warranty)
                elif product_type == '2':
                    size = input("Enter Size (S/M/L/XL): ")
                    color = input("Enter Color: ")
                    product = Clothing(product_id, product_name, description, price, quantity, size, color)
                else:
                    print("Invalid Product Type.")
                    continue

                processor.create_product(admin_user, product)

            elif choice == '3':
                user_id = int(input("Enter your User ID: "))
                order_id = int(input("Enter your Order ID to cancel: "))
                processor.cancel_order(user_id, order_id)

            elif choice == '4':
                products = processor.get_all_products()
                print("\nAll Products:")
                for product in products:
                    print(product)

            elif choice == '5':
                user_id = int(input("Enter your User ID: "))
                username = input("Enter your Username: ")
                password = input("Enter your Password: ")
                role = "User"  # Assuming user role here
                user = User(user_id, username, password, role)
                orders = processor.get_order_by_user(user)
                print("\nOrders by User:")
                for order in orders:
                    print(order)

            elif choice == '6':
                print("Exiting Order Management System. Goodbye!")
                break

            else:
                print("Invalid Choice! Please enter a number between 1 and 6.")
