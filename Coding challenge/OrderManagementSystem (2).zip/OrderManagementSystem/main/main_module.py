from dao.product_service_impl import ProductServiceImpl
from entity.product import Product
from exception.product_not_found_exception import ProductNotFoundException

def main():
    service = ProductServiceImpl()

    while True:
        print("\n1. Add Product\n2. View Product\n3. View All Products\n4. Update Product\n5. Delete Product\n6. Exit")
        choice = input("Enter your choice: ")

        if choice == '1':
            pid = int(input("Product ID: "))
            pname = input("Product Name: ")
            desc = input("Description: ")
            price = float(input("Price: "))
            quantity = int(input("Quantity In Stock: "))
            type_ = input("Type (Electronics/Clothing): ")

            product = Product(pid, pname, desc, price, quantity, type_)
            service.add_product(product)
            print("Product Added Successfully.")

        elif choice == '2':
            pid = int(input("Product ID: "))
            try:
                product = service.get_product_by_id(pid)
                print(product)
            except ProductNotFoundException as e:
                print(e)

        elif choice == '3':
            products = service.get_all_products()
            for p in products:
                print(p)

        elif choice == '4':
            pid = int(input("Product ID to update: "))
            pname = input("New Product Name: ")
            desc = input("New Description: ")
            price = float(input("New Price: "))
            quantity = int(input("New Quantity: "))
            type_ = input("New Type: ")

            product = Product(pid, pname, desc, price, quantity, type_)
            try:
                service.update_product(product)
                print("Product Updated Successfully.")
            except ProductNotFoundException as e:
                print(e)

        elif choice == '5':
            pid = int(input("Product ID to delete: "))
            try:
                service.delete_product(pid)
                print("Product Deleted Successfully.")
            except ProductNotFoundException as e:
                print(e)

        elif choice == '6':
            print("Exiting...")
            break

        else:
            print("Invalid Choice.")

if __name__ == "__main__":
    main()

