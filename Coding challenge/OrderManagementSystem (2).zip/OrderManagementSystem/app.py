from main.order_management import OrderManagement

if __name__ == "__main__":
    OrderManagement.main()
